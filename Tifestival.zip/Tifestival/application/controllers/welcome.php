<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Welcome extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_ticket'); // Memuat model di constructor
	}

	public function index()
	{
		$data = array(
			'title' => 'home',
			'css' => 'home.css',
			'tickets' => $this->m_ticket->get_all_data(),
		);

		$this->load->view('layout/header', $data);
		$this->load->view('home/home', $data);
		$this->load->view('layout/footer');
	}

	public function detail_ticket($id_ticket)
	{
		$data = array(
			'title' => 'Product detail',
			'ticket' => $this->m_ticket->detail_ticket($id_ticket),
		);
		$this->load->view('pembayaran/detail', $data);
	}

	public function about()
	{
		$data = array(
			'title' => 'about',
			'css' => 'about.css'
		);
		$this->load->view('layout/header', $data);
		$this->load->view('home/about', $data);
		$this->load->view('layout/footer');
	}
	public function contact()
	{
		$data = array(
			'title' => 'contact',
			'css' => 'contact.css'
		);
		$this->load->view('layout/header', $data);
		$this->load->view('home/contact', $data);
		$this->load->view('layout/footer');
	}


	public function more()
	{
		$data = array(
			'title' => 'more event',
			'css' => 'more.css',
			'tickets' => $this->m_ticket->get_all_data(),
		);
		$this->load->view('layout/header', $data);
		$this->load->view('home/more', $data);
		$this->load->view('layout/footer');
	}
}
