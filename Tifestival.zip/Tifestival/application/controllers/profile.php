<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Profile extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_user');
        $this->load->model('m_buyer'); // Load the buyer model
        $this->load->library('session'); // Load session library
    }

    public function index()
    {
        $email = $this->session->userdata('email');
        $user = $this->m_user->get_user_by_email($email);

        if ($user) {
            $user_id = $user->user_id;
            $invoice = $this->m_buyer->get_tickets_by_user($user_id);
        } else {
            $invoice = [];
        }

        $data = array(
            'title' => 'Profile',
            'css' => 'profile.css',
            'user' => $user,
            'invoice' => $invoice, // Use 'invoice' consistently
        );


        $this->load->view('profile/user', $data);
    }
}
