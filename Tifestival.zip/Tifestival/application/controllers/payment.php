<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Payment extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_ticket');
        $this->load->model('m_buyer');
        $this->load->library('session'); // Load session library
    }

    public function index($id_ticket, $price)
    {
        if (!$this->session->userdata('user_id')) {
            // User is not logged in, redirect to login page
            redirect('auth');
        }

        $data = array(
            'title' => 'Payment',
            'css' => 'payment.css',
            'ticket' => $this->m_ticket->detail_ticket($id_ticket), // Get ticket details based on $id_ticket
            'price' => $price, // Selected ticket price
        );

        $this->load->view('layout/header', $data);
        $this->load->view('pembayaran/payment', $data);
        $this->load->view('layout/footer');
    }

    public function process_payment()
    {
        if (!$this->session->userdata('user_id')) {
            // User is not logged in, redirect to login page
            redirect('auth');
        }

        $name = $this->input->post('name');
        $email = $this->input->post('email');
        $contact = $this->input->post('contact');
        $method = $this->input->post('method');

        $image = $this->input->post('image');
        $ticket_name = $this->input->post('ticket_name');
        $ticket_date = $this->input->post('ticket_date');
        $ticket_price = $this->input->post('ticket_price');

        // Debugging: Print received form data

        $user_id = $this->session->userdata('user_id'); // Get user ID from session

        $buyer_data = array(
            'name' => $name,
            'email' => $email,
            'contact' => $contact,
            'method' => $method,
            'image' => $image,
            'ticket_name' => $ticket_name,
            'ticket_date' => $ticket_date,
            'ticket_price' => $ticket_price,
            'user_id' => $user_id // Use user_id instead of id to avoid confusion
        );

        $this->m_buyer->insert_buyer($buyer_data); // Call the method in the model to insert data

        // Redirect or load a view after successful insertion
        redirect('profile'); // Change 'success_page' to your success page route
    }
}
