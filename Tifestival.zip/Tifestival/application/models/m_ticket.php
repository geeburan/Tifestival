<?php

defined('BASEPATH') or exit('No direct script access allowed');

class M_ticket extends CI_Model
{
    public function get_all_data()
    {
        $this->db->select('*');
        $this->db->from('ticket');
        $this->db->join('artist', 'artist.id_artist = ticket.id_artist', 'left');
        $this->db->order_by('id_ticket', 'desc');
        return $this->db->get()->result();
    }

    public function detail_ticket($id_ticket)
    {
        $this->db->select('*');
        $this->db->from('ticket');
        $this->db->join('artist', 'artist.id_artist = ticket.id_artist', 'left');
        $this->db->where('id_ticket', $id_ticket);
        $this->db->order_by('id_ticket', 'desc');
        return $this->db->get()->row();
    }
}




/* End of file m_user.php */
