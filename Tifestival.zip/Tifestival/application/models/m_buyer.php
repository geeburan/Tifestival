<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_buyer extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function insert_buyer($data)
    {
        $this->db->insert('invoice', $data);
    }

    public function get_tickets_by_user($user_id)
    {
        $this->db->where('user_id', $user_id);
        $query = $this->db->get('invoice');
        return $query->result();
    }
}
