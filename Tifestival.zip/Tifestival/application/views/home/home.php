	<section class="hero">
		<div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
			<div class="carousel-inner">
				<div class="carousel-item active">
					<img src="<?= base_url("assets/img-home/taylor.png") ?>" class="d-block w-100" alt="...">
				</div>
				<div class="carousel-item">
					<img src="<?= base_url("assets/img-home/blackpink.png") ?>" class="d-block w-100" alt="...">
				</div>
			</div>
		</div>
	</section>

	<section class="intro">
		<h2>Uncover Extraordinary Experiences!</h2>
		<p>Dive into excitement with our top picks of epic events! There’s something extraordinary for everyone.</p>
	</section>

	<section class="events">
		<h2>Most Popular Event:</h2>
		<div class="event-list">
			<?php
			$count = 0;
			foreach ($tickets as $ticket) {
				if ($count >= 3) {
					break;
				} ?>
				<div class="event">
					<img src="<?= base_url("assets/img-home/" . $ticket->image) ?>" alt="Event Image">
					<div class="event-info">
						<h3><?= $ticket->ticket_name ?></h3>
						<p><?= $ticket->location ?></p>
						<p>From: IDR <?= number_format($ticket->silver, 0, ',') ?></p>
						<a href="<?php echo site_url('welcome/detail_ticket/' . $ticket->id_ticket); ?>"><button>Buy Now</button></a>
					</div>
				</div>
			<?php
				$count++;
			} ?>
		</div>
		<a href="<?php echo site_url('welcome/more'); ?>"><button class="see-more">See More Events</button></a>

	</section>