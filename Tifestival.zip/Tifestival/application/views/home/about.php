<section class="hero">
    <img src="<?= base_url("assets/img-about/header.png") ?>" alt="Concert">
</section>
<section class="about">
    <h2>We Are Event Organizer</h2>
    <p>Online event ticket booking system solutions to site visit management</p>
    <div class="services">
        <div class="service">
            <img src="<?= base_url("assets/img-about/dial.png") ?>" alt="Ticketing Services">
            <h3>Ticketing Services</h3>
            <p>Customer Service is available to ensure the convenience of your transactions.</p>
        </div>
        <div class="service">
            <img src="<?= base_url("assets/img-about/globe.png") ?>" alt="Online Ticket">
            <h3>Online Ticket</h3>
            <p>Sell and monitor the tickets you sell, anytime and anywhere.</p>
        </div>
        <div class="service">
            <img src="<?= base_url("assets/img-about/assessment.png") ?>" alt="Sales Report">
            <h3>Sales Report</h3>
            <p>Report your event ticket sales in real time.</p>
        </div>
        <div class="service">
            <img src="<?= base_url("assets/img-about/message.png") ?>" alt="Check-in Ticket">
            <h3>Check-in Ticket</h3>
            <p>Verify accurately through a system that is compatible with your needs.</p>
        </div>
        <div class="service">
            <img src="<?= base_url("assets/img-about/clock.png") ?>" alt="Manage Events">
            <h3>Manage Events</h3>
            <p>Manage your events with dashboard admins for each organizer.</p>
        </div>
        <div class="service">
            <img src="<?= base_url("assets/img-about/dollar.png") ?>" alt="Low Cost">
            <h3>Low Cost</h3>
            <p>Now you can make automatic withdrawals in just 1 working day.</p>
        </div>
    </div>
</section>