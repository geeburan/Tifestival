<section class="contact-section" style="background: url('<?= base_url("assets/img-auth/bg.jpg") ?>') no-repeat center center fixed; background-size: cover; display: flex; justify-content: center; align-items: center; overflow: hidden;">
    <div class="contact-container">
        <h2>Drop us a line</h2>
        <form>
            <label for="name">Name</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>

            <label for="message">Message</label>
            <textarea id="message" name="message" required></textarea>

            <button type="submit">Submit</button>
        </form>
        <div class="contact-info">
            <h2>Contact Us</h2>
            <p>You also can find us from here</p>
            <p><i class="bx bxl-whatsapp"></i> +62 82467753211<br>WhatsApp Message Only</p>
            <p><i class="bx bxl-gmail"></i> T1festival@gmail.com</p>
        </div>
    </div>
</section>