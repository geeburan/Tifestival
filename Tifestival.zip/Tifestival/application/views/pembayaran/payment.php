<main>
    <div class="container">
        <div class="form-container">
            <form class="buyer-details" id="buyer-form" method="POST" action="<?= site_url('payment/process_payment') ?>">
                <h2>Buyer details</h2>
                <label for="name">Name :</label>
                <input type="text" id="name" name="name" placeholder="put your name" required>

                <label for="email">Email :</label>
                <input type="email" id="email" name="email" placeholder="put your gmail" required>

                <label for="contact">Contact :</label>
                <input type="text" id="contact" name="contact" placeholder="put your number" required>

                <label for="method">Method :</label>
                <select id="method" name="method" required>
                    <option value="">Pick an option</option>
                    <option value="BCA">BCA</option>
                    <option value="MANDIRI">MANDIRI</option>
                    <option value="INDOMART">INDOMART</option>
                </select>

                <!-- Hidden fields for ticket details -->
                <input type="hidden" id="image" name="image" value="<?= $ticket->image ?>">
                <input type="hidden" id="ticket_name" name="ticket_name" value="<?= $ticket->ticket_name ?>">
                <input type="hidden" id="ticket_date" name="ticket_date" value="<?= $ticket->date ?>">
                <input type="hidden" id="ticket_price" name="ticket_price" value="<?= $price ?>">

                <div class="buttons">
                    <button type="button" class="back">Back</button>
                    <button type="submit" class="buy">Buy</button>
                </div>
            </form>
        </div>
        <div class="ticket-container">
            <aside class="ticket-details">
                <img src="<?= base_url('assets/img-home/' . $ticket->image) ?>" alt="Taylor Swift: The Eras Tour">
                <h2><?= $ticket->ticket_name ?></h2>
                <p><strong>Date</strong><br><?= $ticket->date ?></p>
                <p><strong>Venue</strong><br><?= $ticket->location ?></p>
                <p><strong>Stage</strong><br><?= $ticket->periode ?></p>
                <p class="ticket-total"><strong>Ticket Total</strong><br>IDR. <?= number_format($price, 0, ',', '.') ?></p>
            </aside>
        </div>
    </div>
</main>