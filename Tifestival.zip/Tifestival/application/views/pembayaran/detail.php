<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tlfestival</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/detail.css') ?>">
</head>

<body>
    <header>
        <div class="header-container">
            <div class="logo">Tlfestival</div>
            <div class="profile"></div>
        </div>
    </header>

    <main>
        <div class="event-details">
            <div class="event-image">
                <img src="<?= base_url("assets/img-home/" . $ticket->image) ?>" alt="Event Cover">
            </div>
            <div class="event-info">
                <h2><?= $ticket->ticket_name ?></h2>
                <ul>
                    <li><strong>Date:</strong> <?= $ticket->date ?></li>
                    <li><strong>Time:</strong> <?= $ticket->periode ?></li>
                    <li><strong>Location:</strong> <?= $ticket->location ?></li>
                </ul>
                <p>Organized by:</p>
                <div class="organizer">Tlfestival</div>
            </div>
        </div>

        <div class="content">
            <div class="ticket-prices">
                <h3>Ticket Price</h3>
                <div class="ticket silver">
                    <div class="ticket-info">
                        <h4>Silver</h4>
                        <p>7th FLOOR</p>
                        <p><?= $ticket->periode ?></p>
                    </div>
                    <div class="ticket-footer">
                        <div class="ticket-price"><?= $ticket->silver ?></div>
                        <a href="<?= site_url('payment/index/' . $ticket->id_ticket . '/' . $ticket->silver) ?>">
                            <button class="buy-now">Buy Now</button>
                        </a>
                    </div>
                </div>
                <div class="ticket gold">
                    <div class="ticket-info">
                        <h4>Gold</h4>
                        <p>7th FLOOR</p>
                        <p><?= $ticket->periode ?></p>
                    </div>
                    <div class="ticket-footer">
                        <div class="ticket-price"><?= $ticket->gold ?></div>
                        <a href="<?= site_url('payment/index/' . $ticket->id_ticket . '/' . $ticket->gold) ?>">
                            <button class="buy-now">Buy Now</button>
                        </a>
                    </div>
                </div>
                <div class="ticket diamond">
                    <div class="ticket-info">
                        <h4>Diamond</h4>
                        <p>7th FLOOR</p>
                        <p><?= $ticket->periode ?></p>
                    </div>
                    <div class="ticket-footer">
                        <div class="ticket-price"><?= $ticket->diamond ?></div>
                        <a href="<?= site_url('payment/index/' . $ticket->id_ticket . '/' . $ticket->diamond) ?>">
                            <button class="buy-now">Buy Now</button>
                        </a>
                    </div>
                </div>
                <div class="ticket platinum">
                    <div class="ticket-info">
                        <h4>Platinum</h4>
                        <p>7th FLOOR</p>
                        <p><?= $ticket->periode ?></p>
                    </div>
                    <div class="ticket-footer">
                        <div class="ticket-price"><?= $ticket->platinum ?></div>
                        <a href="<?= site_url('payment/index/' . $ticket->id_ticket . '/' . $ticket->platinum) ?>">
                            <button class="buy-now">Buy Now</button>
                        </a>
                    </div>
                </div>
                <div class="ticket vvip">
                    <div class="ticket-info">
                        <h4>VVIP</h4>
                        <p>7th FLOOR</p>
                        <p><?= $ticket->periode ?></p>
                    </div>
                    <div class="ticket-footer">
                        <div class="ticket-price"><?= $ticket->vvip ?></div>
                        <a href="<?= site_url('payment/index/' . $ticket->id_ticket . '/' . $ticket->vvip) ?>">
                            <button class="buy-now">Buy Now</button>
                        </a>
                    </div>
                </div>
            </div>

            <div class="seat-map-payment">
                <div class="seat-map">
                    <img src="<?= base_url("assets/img-detail/map.png") ?>" alt="" srcset="">
                </div>
                <div class="payment-method">
                    <h3>Payment Method</h3>
                    <div class="payment-logos">
                        <div class="payment-logo">
                            <img src="<?= base_url("assets/img-detail/pay.png") ?>" alt="" srcset="">
                        </div>
                        <div class="payment-logo">
                            <img src="<?= base_url("assets/img-detail/pay2.png") ?>" alt="" srcset="">
                        </div>
                        <div class="payment-logo">
                            <img src="<?= base_url("assets/img-detail/pay3.png") ?>" alt="" srcset="">
                        </div>
                        <div class="payment-logo">
                            <img src="<?= base_url("assets/img-detail/pay4.png") ?>" alt="" srcset="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="footer-container">Tlfestival</div>
    </footer>
</body>

</html>