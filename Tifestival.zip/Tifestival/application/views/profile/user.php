<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TIfestival</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('assets/css/profile.css') ?>">
</head>

<body>
    <div class="header">
        <div class="left-buttons">
            <a href="<?php echo site_url('welcome'); ?>"><box-icon name='arrow-back' color='#f0ad4e'></box-icon></a>
        </div>
        <h1>TIfestival</h1>
        <div class="right-buttons">
            <a href="<?php echo site_url('auth/logout'); ?>"><box-icon name='log-out' type='solid' color='#f0ad4e'></box-icon></a>
        </div>
    </div>
    <div class="profile-header">
        <img src="<?php echo base_url('assets/img-profile/' . $user->image); ?>" alt="Profile Picture">
        <div>
            <h1><?= $user->name ?></h1>
            <p><?= $user->email ?></p>
        </div>
    </div>
    <div class="nav">
        SEE MORE FUN FESTIVALS
    </div>
    <div class="content">
        <div id="carouselExampleRide" class="carousel slide carousel-fade" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="<?= base_url("assets/img-profile/taylor.png") ?>" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="<?= base_url("assets/img-profile/pink.png") ?>" class="d-block w-100" alt="...">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleRide" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleRide" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
    <div class="purchase-history">
        <?php if (!empty($invoice)) : ?>
            <?php foreach ($invoice as $ticket) : ?>
                <div class="ticket">
                    <img src="<?= base_url("assets/img-home/" . $ticket->image) ?>" alt="<?= $ticket->ticket_name ?>">
                    <div class="ticket-details">
                        <h3><?= $ticket->ticket_name ?></h3>
                        <p>Date: <?= $ticket->ticket_date ?></p>
                        <p>Price: IDR <?= number_format($ticket->ticket_price, 0, ',', '.') ?></p>
                    </div>
                    <div class="status">
                        <button class="finished" data-toggle="modal" data-target="#purchaseModal">Finished purchasing</button>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else : ?>
            <p>No tickets purchased yet.</p>
        <?php endif; ?>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="purchaseModal" tabindex="-1" aria-labelledby="purchaseModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content glassmorphism">
                <div class="modal-header">
                    <h5 class="modal-title" id="purchaseModalLabel">Ticket Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center">
                    <img src="<?= base_url("assets/img-home/" . $ticket->image) ?>" alt="<?= $ticket->ticket_name ?>" class="img-fluid">
                    <h3><?= $ticket->ticket_name ?></h3>
                    <p><?= $ticket->ticket_date ?></p>
                    <hr>
                    <p>Thanks For Buying</p>
                    <img src="<?= base_url("assets/img-profile/barcode.png") ?>" alt="QR Code">
                    <p>Scan This Barcode for Entrance</p>
                    <h4>TIfestival</h4>
                </div>
            </div>
        </div>
    </div>
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>