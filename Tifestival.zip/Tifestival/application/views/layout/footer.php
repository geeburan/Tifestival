<footer>
    <div class="footer-content">
        <img src="<?= base_url("assets/img-home/orang.png") ?>" alt="Person Image">
        <div class="footer-text">
            <p>Worried it will be difficult? <span class="highlight">#MakeItSimple</span><br>With TIfestival</p>
        </div>
    </div>
</footer>

</body>

</html>