<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--boxicon-->
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <title><?= $title ?></title>
    <link rel="stylesheet" href="<?php echo base_url("assets/css/" . $css) ?>">
</head>

<body>
    <header>
        <div class="logo">Tlfestival</div>
        <nav>
            <ul>
                <li><a href="<?php echo site_url('welcome/index'); ?>">Home</a></li>
                <li><a href="<?php echo site_url('welcome/about'); ?>">About</a></li>
                <li><a href="<?php echo site_url('welcome/contact'); ?>">Contact</a></li>
            </ul>
        </nav>
        <div class="profile">
            </li>
            <div class="profile">
                <?php
                if ($this->session->userdata('email')) {
                    // Check the user's role_id and provide the appropriate link
                    $userRoleId = $this->session->userdata('role_id');
                    $redirectUrl = ($userRoleId == 1) ? base_url('admin') : base_url('profile');

                    echo '<a href="' . $redirectUrl . '" class="mx-2"><box-icon name="user-circle" color="#ffe600"></box-icon></a>';
                } else {
                    echo '<a href="' . base_url('auth') . '" class="mx-2"><box-icon name="user-circle" color="#ffe600"></box-icon></a>';
                }
                ?>
            </div>

        </div>
    </header>