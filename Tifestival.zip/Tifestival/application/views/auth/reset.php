<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>Login Page</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/auth.css') ?>">
</head>

<body style="background: url('<?= base_url("assets/img-auth/bg.jpg") ?>') no-repeat center center fixed; background-size: cover; display: flex; justify-content: center; align-items: center; overflow: hidden;">
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <h2>Sign up</h2>
            </div>
            <form>
                <div class="input-group">
                    <label for="email"><box-icon type='solid' name='envelope'></box-icon></i></label>
                    <input type="email" id="email" placeholder="Email">
                </div>
                <div class="input-group">
                    <label for="oldPassword"><box-icon type='solid' name='lock'></box-icon></i></label>
                    <input type="oldPassword" id="oldPassword" placeholder="Old password">
                </div>
                <div class="input-group">
                    <label for="newPassword"><box-icon type='solid' name='lock'></box-icon></label>
                    <input type="newPassword" id="newPassword" placeholder="New password">
                </div>
                <button type="submit">Sign up</button>
                <div class="login-footer">
                    <p>Already have an account?<a href="<?php echo site_url('auth/index'); ?>">Login</a></p>
                </div>
            </form>
        </div>
    </div>
</body>
<!-- boxicon -->
<script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>

</html>