<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>Login Page</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/auth.css') ?>">
</head>

<body style="background: url('<?= base_url("assets/img-auth/bg.jpg") ?>') no-repeat center center fixed; background-size: cover; display: flex; justify-content: center; align-items: center; overflow: hidden;">
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <h2>Login</h2>
            </div>
            <form class="user" action="<?php base_url('auth '); ?>" method="post">
                <?= $this->session->flashdata('message') ?>
                <small class="text-danger"><?= form_error('email') ?></small>
                <div class="input-group">
                    <label><box-icon type='solid' name='envelope'></box-icon></label>
                    <input type="text" id="email" name="email" placeholder="Email" value="<?= set_value('email'); ?>">
                </div>
                <small class="text-danger"><?= form_error('password') ?></small>
                <div class="input-group">
                    <label><box-icon type='solid' name='lock'></box-icon></label>
                    <input type="password" id="password" name="password" placeholder="Password">
                </div>
                <button type="submit">Login</button>
                <div class="login-footer">
                    <p>Don't have an account? <a href="<?php echo site_url('auth/regist'); ?>">Sign Up</a></p>
                    <p><a href="<?php echo site_url('auth/reset'); ?>">Forgot pass</a></p>
                </div>
            </form>
        </div>
    </div>
    <!-- boxicon -->
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
</body>

</html>