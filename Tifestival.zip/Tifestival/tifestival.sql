-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306:3308
-- Waktu pembuatan: 22 Jun 2024 pada 18.42
-- Versi server: 8.0.35
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tifestival`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `artist`
--

CREATE TABLE `artist` (
  `id_artist` int NOT NULL,
  `artist_name` varchar(150) NOT NULL,
  `genre` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `artist`
--

INSERT INTO `artist` (`id_artist`, `artist_name`, `genre`) VALUES
(1, 'Taylor Swift', 'Pop'),
(2, 'Black Pink', 'Kpop'),
(3, 'Michael Jackson', 'Pop'),
(4, 'Efek Rumah Kaca', 'Indie'),
(5, 'Green Day', 'Punk Rock'),
(6, 'Pink floyd', 'Rock'),
(7, 'Nirvana', 'Rock'),
(8, 'Oasis', 'Rock'),
(9, 'The Beatles', 'Pop'),
(10, 'Kendrick Lamar', 'Rap'),
(11, 'J Cole', 'Rap'),
(12, 'Joji', 'RNB');

-- --------------------------------------------------------

--
-- Struktur dari tabel `invoice`
--

CREATE TABLE `invoice` (
  `id_invoice` int NOT NULL,
  `user_id` int NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `contact` int NOT NULL,
  `method` varchar(150) NOT NULL,
  `image` varchar(10) NOT NULL,
  `ticket_name` varchar(150) NOT NULL,
  `ticket_date` varchar(150) NOT NULL,
  `ticket_price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `myitem`
--

CREATE TABLE `myitem` (
  `id_item` int NOT NULL,
  `id_user` int NOT NULL,
  `id_ticket` int NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `role`
--

CREATE TABLE `role` (
  `role_id` int NOT NULL,
  `role` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `role`
--

INSERT INTO `role` (`role_id`, `role`) VALUES
(1, 'admin'),
(2, 'user');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ticket`
--

CREATE TABLE `ticket` (
  `id_ticket` int NOT NULL,
  `ticket_name` varchar(150) NOT NULL,
  `id_artist` int NOT NULL,
  `silver` int NOT NULL,
  `gold` int NOT NULL,
  `diamond` int NOT NULL,
  `platinum` int NOT NULL,
  `vvip` int NOT NULL,
  `date` varchar(150) NOT NULL,
  `location` varchar(150) NOT NULL,
  `periode` varchar(150) NOT NULL,
  `image` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `ticket`
--

INSERT INTO `ticket` (`id_ticket`, `ticket_name`, `id_artist`, `silver`, `gold`, `diamond`, `platinum`, `vvip`, `date`, `location`, `periode`, `image`) VALUES
(1, 'The Eras Tour', 1, 10000000, 15000000, 20000000, 25000000, 30000000, '13 October 2024', 'Los Angeles:California', '10:00 PM', '1.png'),
(2, 'Born Pink', 2, 16000000, 21000000, 26000000, 31000000, 36000000, '11 March 2024', 'Gelora Bung Karno:Jakarta', '07:00 PM', '2.png'),
(3, 'The Big Stepper Tour', 10, 5000000, 10000000, 15000000, 20000000, 25000000, '13 September 2024', 'Stadion JIS:Jakarta', '05:00 PM', '3.png'),
(4, 'Efek rumah Kaca', 4, 700000, 100000, 110000, 150000, 2000000, '5 January 2024', 'Gelora Bung Karno:Jakarta', '02:00 AM', '4.png'),
(5, 'Green Day Tour', 5, 15000000, 20000000, 25000000, 30000000, 35000000, '20 February', 'ICE BSD:Tanggerang', '11:00 AM', '5.png'),
(6, 'Smithereens Tour', 12, 1000000, 1500000, 2000000, 2500000, 3000000, '30 August', 'Gelora Bung Karno:jakarta', '10:00 PM', '6.png'),
(7, 'The Damn Tour', 10, 2000000, 2300000, 2500000, 2700000, 3000000, '14 January 2025', 'ICE BSD:Tanggerang', '06:00 AM', '7.png'),
(8, 'Forrest Hills Drive Tour', 11, 5000000, 5200000, 5500000, 5800000, 6000000, '13 October 2025', 'Stadion JIS:Jakarta', '15:00 AM', '8.png'),
(9, 'Nectar Tour', 12, 500000, 600000, 700000, 800000, 900000, '5 September 2025', 'ICE BSD:Tanggerang', '07:00 PM', '9.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `user_id` int NOT NULL,
  `name` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `image` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `role_id` int NOT NULL,
  `date_created` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`user_id`, `name`, `password`, `email`, `image`, `role_id`, `date_created`) VALUES
(1, 'ZILDJIAN GIBRAN', '$2y$10$HB4ixCNiVqj7hFzu8JfpTuMjXncXXvPQ/yuFr2t/85xe2/Iwuo9zG', 'jian@gmail.com', 'default.png', 2, 1718819531),
(2, 'ZILDJIAN GIBRAN', '$2y$10$pdFVl/sTcttIqhcBenACa.xcG7reK9w4NCzE6f6AZ0F/oeYBVqzam', 'sayajian2004@gmail.com', 'default.png', 2, 1718819800),
(3, 'ZILDJIAN GIBRAN', '$2y$10$gHqqEIFPzzntNOkNF0N31O9wpZwzOOGMfR5kSvqZw.vc/X/8BW7.G', 'agus91@gmail.com', 'default.png', 2, 1718819947),
(4, 'ZILDJIAN GIBRAN', '$2y$10$.nQVqCxwR623B7mPEM/cvu7GMD2KkgkcZNblb/oYevW49wGbQxnGy', 'p@gmail.com', 'default.png', 2, 1718820271),
(5, 'kkkkk', '$2y$10$svomDFMxJ3lx1dwKyGmVN.SGtLeAZD2kquQfGZVh/aKhj14Vls7Bu', 'k@gmail.com', 'default.png', 2, 1718847468);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `artist`
--
ALTER TABLE `artist`
  ADD PRIMARY KEY (`id_artist`);

--
-- Indeks untuk tabel `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`id_invoice`);

--
-- Indeks untuk tabel `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`role_id`);

--
-- Indeks untuk tabel `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`id_ticket`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `artist`
--
ALTER TABLE `artist`
  MODIFY `id_artist` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `invoice`
--
ALTER TABLE `invoice`
  MODIFY `id_invoice` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `role`
--
ALTER TABLE `role`
  MODIFY `role_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `ticket`
--
ALTER TABLE `ticket`
  MODIFY `id_ticket` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
